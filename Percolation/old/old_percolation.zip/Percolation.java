import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
	//state is an array representing the states of each site,
	//if state[i] = false, the site is closed
	private boolean[] state;
	
	//the union find API to compute whether there exists a path between sites
	private WeightedQuickUnionUF uf;
	
	//index of virtual top and bottom sites
	private int VIRTUAL_TOP;
	private int VIRTUAL_BOTTOM;

	//size of the grid (amount of rows and cols)
	private int N;
	
	//number of open sites
	private int nOpenSites;
	
	public Percolation(int _N) {
	    if (_N < 1) throw new IllegalArgumentException();
		
		N = _N;
		
		//initialize every state to false
		state = new boolean[N * N + 2];
		for (int n = 0; n < N * N; n++) {
			state[n] = false;
		}
		
		VIRTUAL_TOP = N * N;
		VIRTUAL_BOTTOM = N * N + 1;
		
		//the last two values in state will be the virtual sites,
		//there is a virtual site on top which is adjacent to all of the sites in the top row,
		//and similarly for the bottom virtual site
		state[VIRTUAL_TOP] = true;
		state[VIRTUAL_BOTTOM] = true;
		
		uf = new WeightedQuickUnionUF(N * N + 2);
		
		nOpenSites = 0;
	}
	
	//given the row and col of a site, return the index of that site in the state variable
	private int index(int row, int col) {
		return row * N + col;
	}
	
	//given the row and col of a site, return the indexes of the neighbors of that site
	//the neighbors being the direct adjacent sites to that site (no diagonals)
	private int[] neighbors(int row, int col) {
		return new int[] {index(row - 1, col), index(row + 1, col), index(row, col - 1), index(row, col + 1)};
	}
	
	//returns if p is a number from 0 to N * N (if p is a valid index)
	private boolean valid(int p) {
		return p >= 0 && p < N * N;
	}
	
	//set the given site to open
	public void open(int row, int col) {
		row -= 1; col -= 1;
		
		if (!inRange(row) || !inRange(col)) {
			return;
		}
		
		int p = index(row, col);
		state[p] = true;
		for (int n = 0; n < 4; n++) {
			//upon opening a site, it should be connected to any open sites adjacent to it
			int q = neighbors(row, col)[n];
			if (valid(q) && state[q]) {
				uf.union(p, q);
			}
		}
		
		if (row == 0) {
			//if the site is in the first row it should be connected to the top virtual site
			uf.union(p, VIRTUAL_TOP);
		} else if (row == N - 1) {
			//if the site is in the last row it should be connected to the bottom virtual site
			uf.union(p, VIRTUAL_BOTTOM);
		}
		
		nOpenSites++;
	}
	
	private boolean inRange(int n) {
		return n >= 0 && n < N;
	}
	
	//returns if a given site is open
	//as a result, it should return the index of the state array
	public boolean isOpen(int row, int col) {
		row -= 1; col -= 1;
		
		if (!inRange(row) || !inRange(col)) {
			return false;
		}
		
		return state[index(row, col)];
	}
	
	//using the uf API, return if two sites are connected
	private boolean connected(int p, int q) {
		return uf.find(p) == uf.find(q);
	}
	
	//return if a certain site is full given its index
	private boolean isFull(int p) {
		return connected(p, VIRTUAL_TOP);
	}
	
	//return if a certain site is full given its coordinates
	public boolean isFull(int row, int col) {
		row -= 1; col -= 1;
		
		if (!inRange(row) || !inRange(col)) {
			return false;
		}
		
		return connected(index(row, col), VIRTUAL_TOP);
	}
	
	//returns the amount of sites that have been opened
	public int numberOfOpenSites() {
		return nOpenSites;
	}
	
	//returns if the system percolates
	//the system percolates if the virtual top and bottom sites are connected
	public boolean percolates() {
		return isFull(VIRTUAL_BOTTOM);
	}
}