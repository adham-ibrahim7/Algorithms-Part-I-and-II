import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
	//N: the size of the grid
	//T: the amount of trials that will be performed
	private int N, T;
	
	//a list of simulations, so as to calculate the mean and stddev
	private double[] simulations;
	public PercolationStats(int n, int trials) {
		N = n;
		T = trials;
		
		simulations = new double[T];
		for (int i = 0; i < T; i++) {
			simulations[i] = simulate();
		}
	}
	
	//a method to simulate just one trial
	//return the simulations value of p*
	private double simulate() {
		Percolation pc = new Percolation(N);
		
		while (!pc.percolates()) {
			//choose a random coordinate and open if its not open already
			int row = StdRandom.uniform(1, N + 1);
			int col = StdRandom.uniform(1, N + 1);
			
			if (!pc.isOpen(row, col)) {
				pc.open(row, col);
			}
		}
		
		//ratio of open sites to total sites
		return ((double) pc.numberOfOpenSites()) / (N * N);
	}
	
	//return the average of the simulations
	//this represents the p* value
	public double mean() {
		return StdStats.mean(simulations);
	}
	
	//return the stddev of the simulations
	//this represents how "sharp" the threshold is
	public double stddev() {
		return StdStats.stddev(simulations);
	}
	
	//the low end of the confidence interval
	public double confidenceLo() {
		return mean() - 1.96 * stddev() / Math.sqrt(T);
	}
	
	//the high end of the confidence interval
	public double confidenceHi() {
		return mean() + 1.96 * stddev() / Math.sqrt(T);
	}
	
	//test client
	public static void main(String[] args) {
		int N = Integer.parseInt(args[0]);
		int T = Integer.parseInt(args[1]);
		PercolationStats ps = new PercolationStats(N, T);
		
		System.out.println(ps.mean());
		System.out.println(ps.stddev());
		System.out.println("[" + ps.confidenceLo() + "," + ps.confidenceHi() + "]");
	}
}