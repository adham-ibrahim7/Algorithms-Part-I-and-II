import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;

/*
 * The Solver class which takes an initial board as input and determines
 * if the board is solvable, and allows for iteration over the solution if
 * there is one
 * 
 * Adham Ibrahim
 * 15/6/20
 */

public class Solver {
	private boolean solvable = true;
	private int moves;
	private List<Board> solution;
	
	/*
	 * Subclass to store a search node as a state
	 *
	 * A state consists of:
	 *    - A current board
	 *    - A link the previous state
	 *    - A "priority" value, for comparison with other states
	 * 
	 * The priority of a state is the sum of the moves it took
	 * to reach the state and the distance the current board is
	 * away from the goal, using the manhattan distance
	 */
	private class State{
		private Board board;
		private State previousState;
		private int moves, priority;
		
		private State(Board board, State previousState, int moves) {
			this.board = board;
			this.previousState = previousState;
			this.moves = moves;
			this.priority = moves + board.manhattan();
		}
	}
	
    /* The A* Algorithm is used here, implemented with a priority queue
     * 
     * The solver maintains a priority queue with the various search states,
     * and always picks the one closest to the goal, using the priority value
     * of the states, and a comparator.
     * 
     * If a board is not solvable, mathematically a twin board will be.
     * So two states are looped over in parallel, and if the twin has a solution,
     * the original is impossible
     * 
     */
	private class AStar {
		
		private State s;
		private MinPQ<State> pq = new MinPQ<State>(new Comparator<State>() {
			public int compare(State a, State b) {
				int d = a.priority - b.priority;
    			return d;//(d == 0) ? a.moves - b.moves : d;
    		}
		});
		
		private AStar(Board initial) {
			s = new State(initial, null, 0);
		}
		
		private boolean found() {
			if (s.board.isGoal()) {
    			return true;
    		}
    		
    		for (Board b : s.board.neighbors()) {
    			if (s.previousState == null || !b.equals(s.previousState.board))
    				pq.insert(new State(b, s, s.moves + 1));
    		}

    		s = pq.delMin();
    		
    		return false;
		}
	}
	
    public Solver(Board initial) {
    	if (initial == null) throw new IllegalArgumentException("null argument to solver");
    	
    	AStar orig = new AStar(initial);
    	AStar twin = new AStar(initial.twin());
    	
    	while (true) {
    		if (orig.found()) {
    			break;
    		} else if (twin.found()) {
    			solvable = false;
    			break;
    		}
    	}
    	
    	if (solvable) {
    		State s = orig.s;
    		moves = s.moves;
        	
        	solution = new ArrayList<Board>();
        	while (s != null) {
        		solution.add(0, s.board);
        		s = s.previousState;
        	}
    	}
    }

    // is the initial board solvable?
    public boolean isSolvable() {
    	return solvable;
    }

    // min number of moves to solve initial board; -1 if unsolvable
    public int moves() {
    	return (solvable) ? moves : -1;
    }

    // sequence of boards in a shortest solution; null if unsolvable
    public Iterable<Board> solution() {
    	if (!solvable) return null;
    	
    	return new Iterable<Board>() {
    		public Iterator<Board> iterator() {
    			return solution.iterator();
    		}
    	};
    }

    // test client (see below) 
    public static void main(String[] args) {
    	//generate random board using RandomizedQueue class
    	/*int N = 3;
    	RandomizedQueue<Integer> rq = new RandomizedQueue<Integer>();
    	for (int i = 0; i < N * N; i++) rq.enqueue(i);
    	
    	int[][] tiles = new int[N][N];
    	for (int i = 0; i < N; i++)
    		for (int j = 0; j < N; j++)
    			tiles[i][j] = rq.dequeue();*/
    	
    	//read from file
    	In in = new In(args[0]);
        int n = in.readInt();
        int[][] tiles = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                tiles[i][j] = in.readInt();
    	
        Board initial = new Board(tiles);
        Solver solver = new Solver(initial);
        
        if (!solver.isSolvable())
            System.out.println("No solution possible");
        else {
        	System.out.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
            	System.out.println(board);
        }
    }

}