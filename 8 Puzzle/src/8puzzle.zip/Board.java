import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * The board class to encapsulate the operations necessary to manipulate 
 * and solve 8-puzzle boards
 * 
 * Adham Ibrahim
 * 15/6/2020
 */

public class Board {
	//size of board
	private int N;
	//the current configuration as a 2d array
	private int[][] tiles;
	
    // create a board from an n-by-n array of tiles,
    // where tiles[row][col] = tile at (row, col)
    public Board(int[][] input) {
    	N = input.length;
    	tiles = new int[N][N];
    	
    	//copy elements so a copy can be made by calling new Board(this.tiles)
    	for (int i = 0; i < N; i++) {
    		tiles[i] = Arrays.copyOf(input[i], N);
    	}
    }
                                           
    // string representation of this board
    public String toString() {
    	String str = Integer.toString(N) + "\n";
    	for (int i = 0; i < N; i++) {
    		for (int j = 0; j < N; j++) {
    			str += " " + Integer.toString(tiles[i][j]);
    		}
    		str += "\n";
    	}
    	
    	return str;
    }

    // board dimension n
    public int dimension() {
    	return N;
    }

    // number of tiles out of place
    public int hamming() {
    	int count = 0;
    	for (int i = 0; i < N; i++)
    		for (int j = 0; j < N; j++)
    			if (tiles[i][j] != 0 && tiles[i][j] != i * N + j + 1) count++;
    	return count;
    }

    // sum of Manhattan distances between tiles and goal
    public int manhattan() {
    	int total = 0;
    	for (int i = 0; i < N; i++) {
    		for (int j = 0; j < N; j++) {
    			int n = tiles[i][j];
    			if (n == 0) continue;
    			//desired i value is n / N, desired j is (n - 1) % N
    			total += Math.abs(i - (n - 1) / N) + Math.abs(j - (n - 1) % N);
    		}
    	}
    	return total;
    }

    // is this board the goal board?
    public boolean isGoal() {
    	//hamming check is quicker
    	return hamming() == 0;
    }

    // does this board equal y?
    public boolean equals(Object o) {
    	if (this == o) return true;
    	if (!(o instanceof Board)) return false;
    	
    	Board b = (Board) o;
    	
    	if (this.dimension() != b.dimension()) return false;
    	
    	for (int i = 0; i < N; i++) {
    		for (int j = 0; j < N; j++) {
    			if (tiles[i][j] != b.tiles[i][j]) {
    				return false;
    			}
    		}
    	}
    	
    	return true;
    }
    
    //position class to easily maninpulate i, j coordinates
    private class Position {
    	
    	int i, j;
    	private Position(int i, int j) {
    		this.i = i; 
    		this.j = j;
    	};
    	
    	private boolean valid() {
    		return i >= 0 && i <= N-1 && j >= 0 && j <= N-1;
    	}
    }
    
    
    //return copy of board with elements swapped
    private Board swap(Position from, Position to) {
    	Board copy = new Board(tiles);
    	
    	int temp = copy.tiles[from.i][from.j];
    	copy.tiles[from.i][from.j] = copy.tiles[to.i][to.j];
    	copy.tiles[to.i][to.j] = temp;
    	
    	return copy;
    }
    
    private Position getEmptyPosition() {
    	Position empty = null;
    	for (int i = 0; i < N; i++) {
    		for (int j = 0; j < N; j++) {
    			if (tiles[i][j] == 0) {
    				empty = new Position(i, j);
    			}
    		}
    	}
    	
    	if (empty == null) throw new RuntimeException("No empty position in board?");
    	
    	return empty;
    }
    

    // all neighboring boards
    public Iterable<Board> neighbors() {
    	List<Board> neighbors = new ArrayList<Board>();
    	
    	Position empty = getEmptyPosition();
    	
    	Position[] possibleNeighbors = new Position[] {new Position(empty.i-1, empty.j), new Position(empty.i+1, empty.j), new Position(empty.i, empty.j-1), new Position(empty.i, empty.j+1)};
    	
    	for (Position possibleNeighbor : possibleNeighbors) {
    		if (possibleNeighbor.valid()) {
    			neighbors.add(swap(empty, possibleNeighbor));
    		}
    	}
    	
    	return new Iterable<Board>() {
    		public Iterator<Board> iterator() {
    			return neighbors.iterator();
    		}
    	};
    }

    // a board that is obtained by exchanging any pair of tiles
    public Board twin() {
    	Position empty = getEmptyPosition();
    	
    	Position first = new Position(0, 0);
    	if (empty.i == 0 && empty.j == 0) first.j = 1;
    	
    	Position second = new Position(N-1, N-1);
    	if (empty.i == N-1 && empty.j == N-1) second.j = N-2;
    	
    	return swap(first, second);
    }

    // unit testing (not graded)
    public static void main(String[] args) {
    	Board b = new Board(new int[][] {{1,2,3},{4,5,6},{7,0,8}});
    	
    	for (Board n : b.neighbors()) {
    		System.out.println(n);
    		System.out.println("------");
    		for (Board m : n.neighbors()) {
    			System.out.println(m);
    		}
    		System.out.println("--------------");
    	}
    }
}